﻿# Geophysical Method Selection Framework - Supplementary Code

## Overview

This package contains the complete Python implementation of the Weighted Sum Model (WSM) framework for geophysical method selection, as described in the manuscript "A Weighted Multi-Criteria Decision Framework for Optimizing Geophysical Method Selection."

## Files

- **geophysical_method_selector_9methods.py**: Core framework implementation with 9 geophysical methods
- **validation_9methods_fixed.py**: Statistical validation module (Spearman ρ, Kendall τ, Kendall's W)
- **actual_expert_rankings_9methods.csv**: Expert ranking data (5 geophysicists, 3 scenarios)
- **framework_rankings_9methods.csv**: Framework-generated rankings
- **validation_results_9methods.csv**: Validation metrics
- **requirements.txt**: Python dependencies

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Basic Example

```python
from geophysical_method_selector_9methods import GeophysicalMethodSelector

selector = GeophysicalMethodSelector()

# Define site parameters
params = {
    'target_depth': 50.0,        # meters
    'conductivity': 100.0,       # mS/m
    'noise_level': 30.0,         # percentage
    'budget': 5000.0,            # USD
    'time_constraint': 3.0       # days
}

# Get ranked methods
rankings = selector.rank_methods(params)

# Display results
for rank, (method, score) in enumerate(rankings, 1):
    print(f"{rank}. {method:25s} (Score: {score:.2f})")
```

### Run Validation

```bash
python validation_9methods_fixed.py
```

## Methods

The framework evaluates 9 geophysical methods:

1. ERT (Electrical Resistivity Tomography)
2. Induced Polarization
3. Self-Potential
4. GPR (Ground Penetrating Radar)
5. TEM (Time-Domain Electromagnetics)
6. Seismic Refraction
7. Magnetometry
8. Gravity
9. Radiometric

## Citation

If you use this code, please cite:

[citation will go here]

## License

MIT License

## Contact

For questions or issues, please contact [melwaheidi@ksu.edu.sa]

